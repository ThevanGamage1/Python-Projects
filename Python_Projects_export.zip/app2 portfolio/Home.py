import streamlit as st
import pandas

st.set_page_config(layout="wide")

col1, col2 = st.columns(2)

with col1:
    st.image("images/photo.png")

with col2:
    st.title("Thevan Gamage")
    content = """Hi, I am Thevan! I am a 5th grader in Edendale Primary School, a basic Python programmer, 
    and a pretty good runner. I was born on August 14th 2013, Sri Lanka, but I was raised in Auckland, New Zealand. I 
    like many things including sports, maths, writing, reading, and many more! But the thing I like the most is 
    sports because of football, running, cricket is sometimes fun for me, and swimming. I have a family of four, 
    including Me, my Sister, my Dad, and my Mom. My Dad owns a business named House Wash New Zealand Ltd. My Mom 
    works for AWF as an accountant, and my sister is also a student but in Balmoral Intermediate School, and in year 
    7. I have 2 unique things including a special tongue which can do 2 things: fold in half, and become a clover 
    shape, I also am double jointed, which means that I can bend one area on my finger and more. Thank you so much!"""
    st.info(content)

content2 = """
Below you can find some of the apps I have built in Python. Feel free to contact me!
"""
st.write(content2)

col3, empty_col, col4 = st.columns([1.5, 0.5, 1.5])

df = pandas.read_csv("data.csv", sep=";")

with col3:
    for index, row in df.iterrows():
        st.header(row["title"])
        st.write(row["description"])
        st.image("images/" + row["image"])
        st.write(f"[Source Code]({row['url']})")


with col4:
    for index, row in df[10:].iterrows():
        st.header(row["title"])
        st.write(row["description"])
        st.image("images/" + row["image"])
        st.write(f"[Source Code]({row['url']})")
