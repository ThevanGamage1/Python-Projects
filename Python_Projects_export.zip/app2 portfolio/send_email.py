import smtplib, ssl


def send_email(message):
    host = "smtp.gmail.com"
    port = 465

    username = "tgamage2023@edendale.school.nz"
    password = "lhfq enax uhln llir"

    receiver = "tgamage2023@edendale.school.nz"
    context = ssl.create_default_context()

    with smtplib.SMTP_SSL(host, port, context=context) as server:
        server.login(username, password)
        server.sendmail(username, receiver, message)
